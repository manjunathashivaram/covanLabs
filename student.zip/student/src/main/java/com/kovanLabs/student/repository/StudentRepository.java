package com.kovanLabs.student.repository;

public interface StudentRepository {

}
