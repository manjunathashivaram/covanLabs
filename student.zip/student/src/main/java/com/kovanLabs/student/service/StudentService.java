package com.kovanLabs.student.service;

import com.kovanLabs.student.entity.Student;

public interface StudentService {
	
	
public  Student saveStudent(Student student);

public Student addStudent(Student student);
	
}
